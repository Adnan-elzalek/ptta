# front_end_back_end_project

## front_end_back_end_project

- https://youtu.be/6hgBFDTTwEk

## php

- https://youtu.be/pszZMzI9a7A
- https://youtu.be/6GGZATzdA2Y
