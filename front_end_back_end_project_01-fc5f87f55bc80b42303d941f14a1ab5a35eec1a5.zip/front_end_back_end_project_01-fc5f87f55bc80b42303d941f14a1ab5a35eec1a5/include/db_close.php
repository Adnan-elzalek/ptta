<?php

mysqli_free_result($result); // memory free variables
mysqli_close($connection);
